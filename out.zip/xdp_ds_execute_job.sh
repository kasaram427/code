#!/bin/sh

#########################################################################################
#   Name:           Database automation script
#   Date:           1st Feb, 2021
#   Description:    Automates the database jobs
#########################################################################################

# Accepting and assigning the command line args
sqldatajobs=$1
running_file=$2
parallel_job=$3
thread=$4
success_stat=0
sleep_time=1
max_sleep_time=10

line_count=`wc -l $sqldatajobs|cut -d" " -f1`

while [ $line_count -gt 1 ]
do
	#sleep $sleep_time
	sleep 2s
	sleep_time=`expr $sleep_time + 1`
	
	if [ "$sleep_time" -gt "$max_sleep_time" ]; then
		sleep_time=1
	fi
	
	itr_no=1
	invalid_itr_no=1
	curr_conn=""
	curr_processing=""
	
	while read line
	do
		if [ "$itr_no" -ne "$invalid_itr_no" ]; then
		
			conn=`echo $line|cut -d';' -f2`
			check=`echo "hi${conn}"`
			
			len=`expr length $check`
			
			if [ "$len" -gt "2" ]; then
				
				processing=`grep $conn $running_file|cut -d';' -f2`
				max_limit=`grep $conn $parallel_job|cut -d';' -f2`
				
				
				if [ "$processing" -lt "$max_limit" ]; then
				
					processing=`expr $processing + 1`
				
					sed -i'.bkp' "/$conn/d" $running_file
					echo "${conn},${processing}" >> $running_file
				
					curr_conn=$conn
					curr_processing=$processing
					break
				
				fi
					
			else
					var=`echo "${itr_no}d"`
					sed -i".bkp" -e "$var" $sqldatajobs
				
			fi
		
		fi
		
		itr_no=`expr $itr_no + 1`
	
	done < $sqldatajobs
	
	check=`echo "hi${curr_conn}"`
	len=`expr length $check`
	if [ "$len" -gt "2" ]; then
	
		row=`grep $curr_conn $sqldatajobs|head -1`
				
		type=`echo $row|cut -d';' -f1`
		con=`echo $row|cut -d';' -f2`
		src=`echo $row|cut -d';' -f3`
		file=`echo $row|cut -d';' -f4`
		
		check_con=`echo "hi${con}"`
		len_con=`expr length $check_con`
	
		check_file=`echo "hi${file}"`
		len_file=`expr length $check_file`
		
		search_string=`echo "${type},${con},${src},${file}"`
		sed -i'.bkp' "/$search_string/d" $sqldatajobs
		
		if [ "$len_con" -gt "2" ]; then
		
			if [ "$len_file" -gt "2" ]; then
			
				curr_dt=`date`
				echo "${curr_dt}: Start executing thread ${thread}"
				sh load.sh $con $file
				last_stat=$?
				
				curr_dt=`date`
				echo "${curr_dt}: End executing thread ${thread}"
				
				if [ "$last_stat" -ne "$success_stat" ]; then
				
					echo $row >> `echo "failed_${sqldatajobs}"`	
					curr_dt=`date`
					echo "${curr_dt}: Job Failed file: ${file}, connection: ${conn}"
					
					curr_processing=`expr $curr_processing - 1`
					
					sed -i'.bkp' "/$curr_conn/d" $running_file
					echo "${curr_conn},${curr_processing}" >> $running_file	
				
				else
				
					curr_processing=`expr $curr_processing - 1`
				
					sed -i'.bkp' "/$curr_conn/d" $running_file
					echo "${curr_conn},${curr_processing}" >> $running_file
					
					echo $row >> `echo "succeeded_${sqldatajobs}"`
				
				fi
			
			fi
		
		fi

	
	fi
	
	sed -i'.bkp' '/^$/d' $sqldatajobs
	line_count=`wc -l $sqldatajobs|cut -d" " -f1`
	
done

rm -f *.bkp

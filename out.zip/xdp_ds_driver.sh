#!/bin/sh

#########################################################################################
#   Name:           Database automation script
#   Date:           1st Feb, 2021
#   Description:    Automates the database jobs
#########################################################################################

# Accepting and assigning the command line args
sqldatajobs="pull_push_check_job.conf"
parallel_job="parallel_job.conf"
unix_system_allowed_jobs=9

# Succeeded and faild sqldatajobs
head -1 $sqldatajobs > `echo "succeeded_${sqldatajobs}"`
head -1 $sqldatajobs > `echo "failed_${sqldatajobs}"`

total_jobs=0
skip_line=1
skip_line_ind=1
while read line
do

	if [ "$skip_line" -ne "$skip_line_ind" ]; then
		jobs=`echo $line|cut -d';' -f2`
		total_jobs=`expr $total_jobs + $jobs`
	fi
	skip_line=`expr $skip_line + 1`
done < parallel_job.conf

if [ "$total_jobs" -lt "$unix_system_allowed_jobs" ]; then
	unix_system_allowed_jobs=$total_jobs
fi

# Prepare sqldatajobs and parallel_job files (remove extra new lines)
echo '' >> $sqldatajobs
echo >> $sqldatajobs
echo >> $parallel_job
echo >> $parallel_job

sed -i'.bkp' '/^$/d' $sqldatajobs
sed -i'.bkp' '/^$/d' $parallel_job

rm -f *.bkp

# Creating job running file to track number of parallel jobs
sed '1d' $parallel_job > temp.csv
running_parallel_job=`echo "running_${parallel_job}"`

rm -f $running_parallel_job 

touch $running_parallel_job

while read line
do
	conn=`echo $line|cut -d';' -f1`
	echo "${conn},0" >> $running_parallel_job
done < temp.csv

rm -f temp.csv

itr_no=1

# Generating threads
while [ $itr_no -le $unix_system_allowed_jobs ]
do

	sh xdp_ds_execute_job.sh $sqldatajobs $running_parallel_job $parallel_job $itr_no &
	
	sleep $itr_no
	
	itr_no=`expr $itr_no + 1`
	
done

# Wait for all threads to finish
wait

rm -f $running_parallel_job

# Setting the success status
exit 0

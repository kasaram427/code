Connection=$1
file=$2

RANDOM=$$
div=2

stats=`expr $RANDOM % $div`

wait_sleep=`expr $stats + 2`

curr_dt=`date`

echo "${curr_dt}: Start loading file: ${file}, connection: ${Connection}"
sleep 10s

curr_dt=`date`
echo "${curr_dt}: End loading file: ${file}, connection: ${Connection}"

exit $stats
